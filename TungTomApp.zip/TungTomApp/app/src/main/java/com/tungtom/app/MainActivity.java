package com.tungtom.app;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.webkit.ScriptHandler;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashSet;
import java.util.Set;
import java.util.function.IntConsumer;

public class MainActivity extends AppCompatActivity {
    private static final String HOME_DEFAULT = "https://pokesurvivor.com/";
    private static final String HOME_DOOF = "https://pokesurvivor.doofcraft.com/";

    private WebView web;
    private FrameLayout root;
    private TextView fab;
    private SharedPreferences prefs;
    private String userScript = "";
    private String bridgeScript = "";
    private ScriptHandler scriptHandler;
    private boolean docStartSupported;

    @SuppressLint({"SetJavaScriptEnabled", "RequiresFeature"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("tt", MODE_PRIVATE);

        userScript = readAsset("TungTom_user.js");
        bridgeScript = readAsset("bridge.js");

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        applyWindowFlags();
        setupWebView();
        setupFab();

        String url = prefs.getString("url", HOME_DEFAULT);
        if (getIntent() != null && getIntent().getData() != null) url = getIntent().getData().toString();
        web.loadUrl(url);
    }

    // ---------- WebView + tiêm userscript ----------
    @SuppressLint({"SetJavaScriptEnabled", "RequiresFeature"})
    private void setupWebView() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        WebView.setWebContentsDebuggingEnabled(true);

        docStartSupported = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);
        if (docStartSupported) registerDocStart();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String sc = u.getScheme();
                if ("http".equals(sc) || "https".equals(sc)) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }

            @Override
            public void onPageStarted(WebView v, String url, android.graphics.Bitmap icon) {
                // Máy không hỗ trợ document-start script: tiêm muộn hơn một chút (hook.js có thể trượt)
                if (!docStartSupported && isGameUrl(url)) v.evaluateJavascript(fullScript(), null);
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                if (isGameUrl(url)) prefs.edit().putString("url", url).apply();
            }
        });
    }

    private boolean isGameUrl(String url) {
        if (url == null) return false;
        Uri u = Uri.parse(url);
        String h = u.getHost() == null ? "" : u.getHost();
        return h.equals("pokesurvivor.com") || h.equals("www.pokesurvivor.com") || h.equals("pokesurvivor.doofcraft.com");
    }

    private String fullScript() {
        return "window.__TT_HIDE=" + prefs.getBoolean("hidePanel", true) + ";\n" + bridgeScript + "\n" + userScript;
    }

    @SuppressLint("RequiresFeature")
    private void registerDocStart() {
        if (scriptHandler != null) scriptHandler.remove();
        Set<String> origins = new HashSet<>();
        origins.add("https://pokesurvivor.com");
        origins.add("https://www.pokesurvivor.com");
        origins.add("https://pokesurvivor.doofcraft.com");
        scriptHandler = WebViewCompat.addDocumentStartJavaScript(web, fullScript(), origins);
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private void js(String code) {
        web.evaluateJavascript(code, null);
    }

    // ---------- cửa sổ: toàn màn hình, giữ sáng ----------
    private void applyWindowFlags() {
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), root);
        if (prefs.getBoolean("fullscreen", true)) {
            c.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars());
            c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        } else {
            c.show(androidx.core.view.WindowInsetsCompat.Type.systemBars());
        }
        if (prefs.getBoolean("keepAwake", true)) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyWindowFlags();
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else openMenu();   // Back ở trang đầu: mở menu thay vì thoát nhầm
    }

    @Override
    protected void onDestroy() {
        if (web != null) { root.removeView(web); web.destroy(); }
        super.onDestroy();
    }

    // ---------- nút nổi 🍤 (kéo được, chạm = mở menu) ----------
    @SuppressLint("ClickableViewAccessibility")
    private void setupFab() {
        fab = new TextView(this);
        fab.setText("🍤");
        fab.setTextSize(20);
        fab.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(0xAA141A22);
        bg.setStroke(dp(1), 0xFF3A4553);
        fab.setBackground(bg);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(44), dp(44));
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.topMargin = dp(8);
        lp.rightMargin = dp(8);
        root.addView(fab, lp);

        final float[] down = new float[4];
        final boolean[] moved = new boolean[1];
        fab.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    down[0] = e.getRawX(); down[1] = e.getRawY();
                    down[2] = v.getX();    down[3] = v.getY();
                    moved[0] = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = e.getRawX() - down[0], dy = e.getRawY() - down[1];
                    if (Math.abs(dx) + Math.abs(dy) > dp(8)) moved[0] = true;
                    if (moved[0]) {
                        v.setX(Math.max(0, Math.min(root.getWidth() - v.getWidth(), down[2] + dx)));
                        v.setY(Math.max(0, Math.min(root.getHeight() - v.getHeight(), down[3] + dy)));
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved[0]) openMenu();
                    return true;
                default:
                    return true;
            }
        });
    }

    // ---------- menu native ----------
    private void openMenu() {
        // Lấy trạng thái hiện tại của bot / Lite / chế độ chơi một lần rồi dựng menu
        String q = "(function(){try{var o={host:location.hostname};"
                + "if(window.PSLite)o.lite=PSLite.get();"
                + "if(window.PSBot){var s=PSBot.state;o.bot={on:!!s.on,done:s.done,target:s.target,debug:!!s.debug};}"
                + "try{o.run=JSON.parse(localStorage.getItem('psbot.dcRun')||'{}');}catch(e){o.run={};}"
                + "return o;}catch(e){return {};}})()";
        web.evaluateJavascript(q, value -> {
            JSONObject st;
            try { st = new JSONObject(value == null || value.equals("null") ? "{}" : value); }
            catch (Exception e) { st = new JSONObject(); }
            showMenu(st);
        });
    }

    private void showMenu(JSONObject st) {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(14), dp(12), dp(14), dp(14));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF141A22);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), 0xFF2E3845);
        col.setBackground(bg);

        JSONObject bot = st.optJSONObject("bot");
        JSONObject lite = st.optJSONObject("lite");
        JSONObject run = st.optJSONObject("run");
        String host = st.optString("host", "");

        col.addView(title("🍤 TungTom v1.11.0"));
        String status;
        if (bot == null) status = "Bot: chưa tải (đợi game vào xong rồi mở lại menu)";
        else status = "Bot: " + (bot.optBoolean("on") ? "ĐANG CHẠY" : "dừng")
                + " · ván " + (bot.optInt("done") + 1)
                + (bot.optInt("target") > 0 ? "/" + bot.optInt("target") : "");
        col.addView(muted(status));

        // --- Bot ---
        col.addView(section("Bot"));
        LinearLayout runsRow = row();
        runsRow.addView(muted("Số ván (0 = vô hạn)"), new LinearLayout.LayoutParams(0, -2, 1));
        final EditText runs = new EditText(this);
        runs.setInputType(InputType.TYPE_CLASS_NUMBER);
        runs.setText(String.valueOf(prefs.getInt("runs", 5)));
        runs.setTextColor(Color.WHITE);
        runs.setGravity(Gravity.CENTER);
        runs.setSingleLine(true);
        runsRow.addView(runs, new LinearLayout.LayoutParams(dp(70), -2));
        col.addView(runsRow);

        LinearLayout b1 = row();
        b1.addView(btn("▶ Chơi", 0xFF1F4A33, 0xFF7EE2A8, v -> {
            int n = 5;
            try { n = Integer.parseInt(runs.getText().toString().trim()); } catch (Exception ignored) {}
            prefs.edit().putInt("runs", n).apply();
            botCall("PSBot.play(" + n + ")");
            d.dismiss();
        }));
        b1.addView(btn("⏸ Tạm dừng", v -> { botCall("PSBot.pause()"); d.dismiss(); }));
        b1.addView(btn("⏯ Tiếp tục", v -> { botCall("PSBot.resume()"); d.dismiss(); }));
        b1.addView(btn("■ Dừng", 0xFF4D2429, 0xFFFF9A9A, v -> { botCall("PSBot.stop()"); d.dismiss(); }));
        col.addView(b1);

        col.addView(sw("Hiện overlay debug trên màn hình", bot != null && bot.optBoolean("debug"),
                (b, on) -> botCall("PSBot.state.debug=" + on)));

        // --- Chế độ ván (doofcraft) ---
        if (host.contains("doofcraft")) {
            col.addView(section("Chế độ ván (doofcraft)"));
            col.addView(muted("Chế độ"));
            col.addView(segment(new String[]{"Game", "Normal", "Waves"},
                    idx(new String[]{"game", "normal", "waves"}, run == null ? "game" : run.optString("mode", "game")),
                    i -> setRun("mode", new String[]{"game", "normal", "waves"}[i])));
            col.addView(muted("Độ khó"));
            col.addView(segment(new String[]{"Game", "Easy", "Medium", "Hard"},
                    idx(new String[]{"game", "easy", "medium", "hard"}, run == null ? "game" : run.optString("difficulty", "game")),
                    i -> setRun("difficulty", new String[]{"game", "easy", "medium", "hard"}[i])));
            col.addView(muted("HYPER"));
            col.addView(segment(new String[]{"Game", "Tắt", "Bật"},
                    idx(new String[]{"game", "off", "on"}, run == null ? "game" : run.optString("hyper", "game")),
                    i -> setRun("hyper", new String[]{"game", "off", "on"}[i])));
        }

        // --- Giảm lag (PSLite) ---
        col.addView(section("Giảm lag / xoá hiệu ứng"));
        if (lite == null) {
            col.addView(muted("Chưa tải xong trang game."));
        } else {
            LinearLayout pr = row();
            pr.addView(btn("Tắt", v -> { liteCall("PSLite.preset('off')"); d.dismiss(); }));
            pr.addView(btn("Nhẹ", v -> { liteCall("PSLite.preset('light')"); d.dismiss(); }));
            pr.addView(btn("Mạnh", v -> { liteCall("PSLite.preset('strong')"); d.dismiss(); }));
            pr.addView(btn("Tối đa", v -> { liteCall("PSLite.preset('max')"); d.dismiss(); }));
            col.addView(pr);
            col.addView(liteSwitch("Xoá hiệu ứng (fx)", "fx", lite));
            col.addView(liteSwitch("Tắt bóng / blur", "shadow", lite));
            col.addView(liteSwitch("Tắt glow", "glow", lite));
            col.addView(liteSwitch("Tắt số damage / bụi", "part", lite));
            col.addView(liteSwitch("CSS không animation", "css", lite));
            col.addView(liteSwitch("Pixel art (không làm mịn)", "pixel", lite));
            col.addView(liteSwitch("Không vẽ nền map", "bg", lite));

            col.addView(muted("Độ phân giải (dpr)"));
            final double[] dprs = {0, 0.5, 0.75, 1};
            int di = 0;
            for (int i = 0; i < dprs.length; i++) if (Math.abs(dprs[i] - lite.optDouble("dpr", 0)) < 0.001) di = i;
            col.addView(segment(new String[]{"Gốc", "0.5", "0.75", "1"}, di, i -> liteCall("PSLite.set({dpr:" + dprs[i] + "})")));

            col.addView(muted("Bỏ khung hình (vẽ 1 trên N khung)"));
            col.addView(segment(new String[]{"1", "2", "3", "4"}, Math.max(0, Math.min(3, lite.optInt("skip", 1) - 1)),
                    i -> liteCall("PSLite.set({skip:" + (i + 1) + "})")));

            col.addView(muted("Ẩn địch"));
            col.addView(segment(new String[]{"Tắt", "Ở xa", "Tất cả"}, Math.max(0, Math.min(2, lite.optInt("hide", 0))),
                    i -> liteCall("PSLite.set({hide:" + i + "})")));

            col.addView(muted("Giới hạn FPS (làm chậm game)"));
            final int[] fpss = {0, 45, 30, 20};
            int fi = 0;
            for (int i = 0; i < fpss.length; i++) if (fpss[i] == lite.optInt("fps", 0)) fi = i;
            col.addView(segment(new String[]{"Tắt", "45", "30", "20"}, fi, i -> liteCall("PSLite.set({fps:" + fpss[i] + "})")));
        }

        // --- Trang ---
        col.addView(section("Trang"));
        LinearLayout n1 = row();
        n1.addView(btn("pokesurvivor.com", v -> { d.dismiss(); web.loadUrl(HOME_DEFAULT); }));
        n1.addView(btn("doofcraft", v -> { d.dismiss(); web.loadUrl(HOME_DOOF); }));
        n1.addView(btn("⟳ Tải lại", v -> { d.dismiss(); web.reload(); }));
        col.addView(n1);

        // --- App ---
        col.addView(section("Ứng dụng"));
        col.addView(sw("Ẩn bảng điều khiển trong trang (dùng menu này)", prefs.getBoolean("hidePanel", true), (b, on) -> {
            prefs.edit().putBoolean("hidePanel", on).apply();
            js("window.__TT&&__TT.hide(" + on + ")");
            if (docStartSupported) registerDocStart();
        }));
        col.addView(sw("Giữ màn hình sáng", prefs.getBoolean("keepAwake", true), (b, on) -> {
            prefs.edit().putBoolean("keepAwake", on).apply();
            applyWindowFlags();
        }));
        col.addView(sw("Toàn màn hình", prefs.getBoolean("fullscreen", true), (b, on) -> {
            prefs.edit().putBoolean("fullscreen", on).apply();
            applyWindowFlags();
        }));
        LinearLayout n2 = row();
        n2.addView(btn("Xoá dữ liệu trang", 0xFF4D2429, 0xFFFF9A9A, v -> {
            d.dismiss();
            web.clearCache(true);
            android.webkit.WebStorage.getInstance().deleteAllData();
            CookieManager.getInstance().removeAllCookies(null);
            Toast.makeText(this, "Đã xoá dữ liệu & cookie. Đang tải lại…", Toast.LENGTH_SHORT).show();
            web.reload();
        }));
        n2.addView(btn("Thoát app", v -> { d.dismiss(); finishAffinity(); }));
        col.addView(n2);

        ScrollView sv = new ScrollView(this);
        sv.addView(col);
        d.setContentView(sv);

        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawableResource(android.R.color.transparent);
            DisplayMetrics dm = getResources().getDisplayMetrics();
            w.setLayout(Math.min(dm.widthPixels - dp(16), dp(420)), (int) (dm.heightPixels * 0.92f));
            w.setGravity(Gravity.CENTER);
        }
        d.show();
    }

    private void botCall(String code) {
        js("(function(){if(!window.PSBot)return 'nobot';" + code + ";return 'ok'})()");
    }

    private void liteCall(String code) {
        js("(function(){if(!window.PSLite)return 'nolite';" + code + ";return 'ok'})()");
    }

    private void setRun(String key, String val) {
        js("(function(){try{var k='psbot.dcRun',o=JSON.parse(localStorage.getItem(k)||'{}');o['" + key + "']='" + val
                + "';localStorage.setItem(k,JSON.stringify(o))}catch(e){}})()");
    }

    private int idx(String[] arr, String v) {
        for (int i = 0; i < arr.length; i++) if (arr[i].equals(v)) return i;
        return 0;
    }

    // ---------- helpers dựng UI ----------
    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView title(String t) {
        TextView tv = new TextView(this);
        tv.setText(t);
        tv.setTextColor(0xFF8FB4FF);
        tv.setTextSize(16);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        return tv;
    }

    private TextView section(String t) {
        TextView tv = new TextView(this);
        tv.setText(t.toUpperCase());
        tv.setTextColor(0xFF8D99A8);
        tv.setTextSize(11);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setPadding(0, dp(14), 0, dp(4));
        return tv;
    }

    private TextView muted(String t) {
        TextView tv = new TextView(this);
        tv.setText(t);
        tv.setTextColor(0xFFB9C3D0);
        tv.setTextSize(12);
        tv.setPadding(0, dp(3), 0, dp(1));
        return tv;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private Button btn(String t, View.OnClickListener l) {
        return btn(t, 0xFF1D2530, 0xFFE6EBF2, l);
    }

    private Button btn(String t, int bgc, int fg, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setTextColor(fg);
        b.setPadding(dp(4), 0, dp(4), 0);
        b.setMinHeight(0);
        b.setMinimumHeight(dp(38));
        GradientDrawable g = new GradientDrawable();
        g.setColor(bgc);
        g.setCornerRadius(dp(8));
        g.setStroke(dp(1), 0xFF3A4553);
        b.setBackground(g);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
        lp.setMargins(dp(2), dp(2), dp(2), dp(2));
        b.setLayoutParams(lp);
        return b;
    }

    private Switch sw(String t, boolean on, CompoundButton.OnCheckedChangeListener l) {
        Switch s = new Switch(this);
        s.setText(t);
        s.setTextColor(0xFFE6EBF2);
        s.setTextSize(13);
        s.setChecked(on);
        s.setPadding(0, dp(6), 0, dp(6));
        s.setOnCheckedChangeListener(l);
        return s;
    }

    private Switch liteSwitch(String t, final String key, JSONObject lite) {
        return sw(t, lite.optBoolean(key), (b, on) -> liteCall("PSLite.set({" + key + ":" + on + "})"));
    }

    // Hàng nút chọn 1 trong N; nút đang chọn được tô vàng
    private LinearLayout segment(String[] labels, int selected, IntConsumer pick) {
        final LinearLayout l = row();
        final Button[] bs = new Button[labels.length];
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            bs[i] = btn(labels[i], v -> {
                for (int j = 0; j < bs.length; j++) paint(bs[j], j == idx);
                pick.accept(idx);
            });
            paint(bs[i], i == selected);
            l.addView(bs[i]);
        }
        return l;
    }

    private void paint(Button b, boolean sel) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(sel ? 0xFF3A3016 : 0xFF1D2530);
        g.setCornerRadius(dp(8));
        g.setStroke(dp(1), sel ? 0xFFFFCC33 : 0xFF3A4553);
        b.setBackground(g);
        b.setTextColor(sel ? 0xFFFFCC33 : 0xFFE6EBF2);
    }
}
