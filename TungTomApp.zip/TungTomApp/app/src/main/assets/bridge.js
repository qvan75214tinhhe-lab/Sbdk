// Cầu nối app <-> trang: ẩn/hiện bảng điều khiển gốc của userscript (menu đã chuyển sang app).
// window.__TT_HIDE do MainActivity đặt ngay trước file này.
(function () {
  if (window.__TT) return;
  var st = null;
  function apply() {
    var root = document.head || document.documentElement;
    if (!root) return;
    if (window.__TT_HIDE && !st) {
      st = document.createElement('style');
      st.textContent = '[data-psbot-dock]{display:none!important}';
      root.appendChild(st);
    } else if (!window.__TT_HIDE && st) {
      st.remove();
      st = null;
    }
  }
  window.__TT = { hide: function (b) { window.__TT_HIDE = !!b; apply(); } };
  apply();
  document.addEventListener('DOMContentLoaded', apply);
})();
