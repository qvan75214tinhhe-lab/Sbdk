# TungTom APK

App Android (WebView) chạy userscript **TungTom v1.11.0** cho pokesurvivor.com / pokesurvivor.doofcraft.com.
Menu điều khiển nằm trong app (nút 🍤 kéo được ở góc màn hình) thay cho bảng trong trang.

## Build APK
**Cách 1 – GitHub Actions (không cần máy tính):** tạo repo GitHub, upload toàn bộ thư mục này
(giữ nguyên `.github/`), vào tab *Actions* → *Build APK* → tải artifact `TungTom-apk`.

**Cách 2 – Android Studio:** Open thư mục này → Build → Build APK(s) → `app/build/outputs/apk/debug/`.

## Cập nhật script
Chép đè `app/src/main/assets/TungTom_user.js` rồi build lại.

## Lưu ý
- Userscript được tiêm ở document-start (giống Via/Tampermonkey), nên hook game hoạt động như bản gốc.
- Nút "Xuất data.js" (tải file) của bảng F6 không dùng được trong WebView; phím F6–F9 cũng không có trên điện thoại.
- Gốc: damhieu2808/PokeSurvivorTool (MIT).
